import java.io.*;
import java.util.*;

public class Kaisar {
    public static void main(String args[]) {
        Scanner scan = new Scanner(System.in);
        String kataAwal = scan.nextLine();
        int N = scan.nextInt();
        String kataBaru ="";
        System.out.println(pergeseran(kataBaru,N,kataAwal));
    }
    public static String pergeseran (String kataBaru, int N, String kataAwal){
        kataBaru = "";
        char huruf;
        for(int i=0; i < kataAwal.length();i++){
            huruf = kataAwal.charAt(i);
            if(huruf >= 'a' && huruf <= 'z'){
                huruf = (char) (huruf + N);
                if(huruf > 'z') {
                    huruf = (char) (huruf+'a'-'z'-1);
                }
                kataBaru = kataBaru + huruf;
            }
            else if(huruf >= 'A' && huruf <= 'Z') {
                huruf = (char) (huruf + N);
                if(huruf > 'Z') {
                    huruf = (char) (huruf+'A'-'Z'-1);
                }
                kataBaru = kataBaru + huruf;
            }else {
                kataBaru = kataBaru + huruf;
            }
        }
        return kataBaru;
    }
}
