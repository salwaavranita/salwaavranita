import java.io.*;
import java.util.*;

public class Saldo {
    public static void main(String[] args) {
        Scanner scan = new Scanner (System.in);
        double saldoAwal = scan.nextDouble();
        double saldoBaru = scan.nextDouble();

        System.out.println(saldo(saldoAwal, saldoBaru));
    }
    public static double potongan(double saldoAwal, double saldoBaru) {
        double saldoSekarang = saldoAwal + saldoBaru;
        double admin = saldoSekarang - 7000;
        return admin;
    }
    public static double saldo(double saldoAwal, double saldoBaru){
        double bonus = 0.0005;
        double saldoFix = potongan(saldoAwal, saldoBaru) * bonus;
        double saldoAkhir = potongan(saldoAwal, saldoBaru) + saldoFix;
        return saldoAkhir;
    }
}
