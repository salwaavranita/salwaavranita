package com.prak8;
import java.util.ArrayList;

public class CarData {
    public static ArrayList<Car> carList= new ArrayList<>();

    public void addCar(String carType, String polNum, String merk){
        carList.add(new Car(carType,polNum,merk));
    }
    public void listOfCar(){
        System.out.println("-------------------------------");
        System.out.println("\t\t DAFTAR MOBIL \t\t");
        System.out.println("-------------------------------");
        for (Car data : CarData.carList) {
            System.out.println("TIPE MOBIL  : " + data.getCarType());
            System.out.println("NO.POLIS    : " + data.getPolNum());
            System.out.println("MERK MOBIL  : " + data.getMerk());
            System.out.println("-------------------------------");
        }
    }
}

