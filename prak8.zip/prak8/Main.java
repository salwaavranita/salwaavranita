package com.prak8;

public class Main {

    public static void main(String[] args) {
	CarRider ming = new CarRider ("Lin Ming", 19, "08000000000");
    CarRider young = new CarRider ("Bei Youhan", 20, "08111111111");
    CarRider ling = new CarRider ("Ling'er", 19, "08222222222");
    CarRider xiu = new CarRider ("Chu Xiu", 33, "08333333333");

    CarData data = new CarData();
    data.addCar("SUV", "N 1111 AB", "Honda");
    data.addCar("SPORT", "N 2222 AB", "SCC Tuatara");
    data.addCar("TRUCK", "N 3333 AB", "Suzuki");
    data.addCar("MPV", "N 4444 AB", "Toyota");

    data.listOfCar();

    RentArchive arsip = new RentArchive();
    arsip.Rent(ming, data.carList.get(1), 9);
    arsip.Rent(young, data.carList.get(0), 3);
    arsip.Rent(ling, data.carList.get(1), 1);
    arsip.Rent(xiu, data.carList.get(2), 4);

    System.out.println();
    Car.status();

    System.out.println("");
    arsip.info();
    }
}
