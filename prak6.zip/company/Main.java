package com.company;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Nama\t : Yanuarin Salwa Afranita");
        System.out.println("NIM\t\t : 215150600111018");
        System.out.println();

        DataMerchant.merc = DataMerchant.tambahMerchant(new Merchant("Bakso Pak Sahid", "Bakso", 8000));
        DataMerchant.merc = DataMerchant.tambahMerchant(new Merchant("Nasgor Mblebes", "Nasi Goreng Jawa", 10000));
        DataMerchant.merc = DataMerchant.tambahMerchant(new Merchant("Ayam Geprek Kak Ros", "Ayam Kota Ekstra Nasi", 10000));
        System.out.println("Tambahan : ");
        System.out.println("Nama Merchant, Nama Produk, Harga Makanan :");
        DataMerchant.merc = DataMerchant.tambahMerchant(new Merchant(scan.nextLine(), scan.nextLine(), scan.nextDouble()));
        DataMerchant.tampilData();
    }
}
