import java.io.*;
import java.util.*;

public class Solution {
    public static void main(String[] args) {
        Scanner scan = new Scanner (System.in);
        int menu = scan.nextInt();

        Solution obj = new Solution();
        if (menu == 1) {
            int sisi = scan.nextInt();
            System.out.println(obj.luasPersegi(sisi));
        } else if (menu == 2) {
            int alas = scan.nextInt();
            int tinggi = scan.nextInt();
            System.out.println(obj.luasSegitiga(alas, tinggi));
        } else if (menu == 3) {
            double r = scan.nextDouble();
            System.out.println(obj.luasLingkaran(r));
        } else {
            System.out.println("Input yang anda masukan tidak sesuai");
        }
    }
    public static int luasPersegi(int sisi){
        int hasil = sisi * sisi;
        return hasil;
    }

    public static int luasSegitiga(int alas, int tinggi){
        double hasil = 0.5 * alas * tinggi;
        int luas = (int) hasil;
        return luas;
    }

    public static double luasLingkaran(double r){
        if (r % 7 == 0){
            double hasil = 22/7 * r * r;
            int luas = (int) hasil;
            return luas;
        } else {
            double hasil = 3.14 * r * r;
            int luas = (int) hasil;
            return luas;
        }
    }
}
